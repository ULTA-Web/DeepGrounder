## Train via command line
#accelerate launch --config_file=recipes/accelerate_configs/zero3.yaml src/open_r1/sft.py \
#    --model_name_or_path Qwen/Qwen2.5-1.5B-Instruct \
#    --dataset_name HuggingFaceH4/Bespoke-Stratos-17k \
#    --learning_rate 2.0e-5 \
#    --num_train_epochs 1 \
#    --packing \
#    --max_seq_length 4096 \
#    --per_device_train_batch_size 2 \
#    --gradient_accumulation_steps 8 \
#    --gradient_checkpointing \
#    --bf16 \
#    --output_dir data/Qwen2.5-1.5B-Open-R1-Distill

# Train via YAML config
accelerate launch --config_file /mnt/user/zhangjiafan/VLM-R1-main/src/open-r1-multimodal/configs/zero3.yaml /mnt/user/zhangjiafan/VLM-R1-main/src/open-r1-multimodal/src/open_r1/sft.py \
    --config /mnt/user/zhangjiafan/VLM-R1-main/src/open-r1-multimodal/configs/qwen2vl_sft_config.yaml
