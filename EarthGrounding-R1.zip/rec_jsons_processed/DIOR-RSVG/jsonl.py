import json
# 读取JSON文件
with open("val_samples.json", "r") as f:
    data = json.load(f)
# 写入JSONL文件
with open("val_rsvg.jsonl", "w") as f:
    for item in data:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")